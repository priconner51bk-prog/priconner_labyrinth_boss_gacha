"""Decision safety gates."""
