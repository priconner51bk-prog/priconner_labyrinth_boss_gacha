"""Offline evaluation utilities."""
