"""対象ボス組み合わせの抽選・撤退判断を独立して扱う。"""

from __future__ import annotations

import json
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import Any

HARD_MAX_ATTEMPTS = 1000


@dataclass(frozen=True)
class BossGachaPolicy:
    target_bosses: Mapping[str, str]
    max_attempts: int = 1000
    allowed_bosses: Mapping[str, Sequence[str]] | None = None

    def __post_init__(self) -> None:
        if self.max_attempts < 1:
            raise ValueError("max_attempts must be positive")
        if self.max_attempts > HARD_MAX_ATTEMPTS:
            raise ValueError(f"max_attempts must be <= {HARD_MAX_ATTEMPTS}")
        if not self.target_bosses:
            raise ValueError("target_bosses must not be empty")
        if self.allowed_bosses is not None:
            if set(self.allowed_bosses) != set(self.target_bosses):
                raise ValueError("allowed_bosses areas must match target_bosses")
            for area, names in self.allowed_bosses.items():
                if (isinstance(names, (str, bytes)) or not isinstance(names, Sequence)
                        or not names or any(not isinstance(name, str) or not name.strip()
                                         for name in names)):
                    raise ValueError(f"allowed_bosses[{area}] must contain non-empty boss names")

    @classmethod
    def from_json(cls, path: str | Path) -> BossGachaPolicy:
        data = json.loads(Path(path).read_text(encoding="utf-8"))
        allowed = data.get("allowed_bosses")
        if "allowed_bosses" in data and not isinstance(allowed, Mapping):
            raise ValueError("allowed_bosses must be an object")
        return cls(
            target_bosses={str(k): str(v) for k, v in data["target_bosses"].items()},
            max_attempts=int(data.get("max_attempts", 1000)),
            allowed_bosses={str(k): names for k, names in allowed.items()}
            if isinstance(allowed, Mapping) else None,
        )


class BossGachaController:
    """画面操作を持たない純粋なボス組み合わせ判定器。"""

    def __init__(self, policy: BossGachaPolicy, attempts: int = 0) -> None:
        if attempts < 0:
            raise ValueError("attempts must be non-negative")
        self.policy = policy
        self.attempts = attempts

    def evaluate(self, boss_names: Mapping[str | int, str]) -> dict[str, Any]:
        self.attempts += 1
        observed = {str(k): str(v) for k, v in boss_names.items()}
        missing = sorted(set(self.policy.target_bosses) - set(observed))
        if missing:
            return {"status": "safety_stop", "reason": "boss_names_missing", "attempt": self.attempts}
        allowed = self.policy.allowed_bosses or {
            area: (expected,) for area, expected in self.policy.target_bosses.items()
        }
        mismatches = {
            area: {"expected": list(names), "observed": observed[area]}
            for area, names in allowed.items()
            if observed.get(area) not in names
        }
        if not mismatches:
            return {"status": "matched", "attempt": self.attempts}
        if self.attempts >= self.policy.max_attempts:
            return {"status": "max_attempts", "attempt": self.attempts, "mismatches": mismatches}
        return {"status": "withdraw_and_retry", "attempt": self.attempts, "mismatches": mismatches}
