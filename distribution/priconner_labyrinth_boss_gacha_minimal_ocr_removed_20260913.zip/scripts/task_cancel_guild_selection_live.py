"""ギルド選択確認をキャンセルし、ギルド一覧へ安全に戻る。"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

import cv2

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT))
from decision.timing import AdaptiveWaitPolicy
from scripts.labyrinth_route import run_adb_coordinate_sequence
from vision.capture import AdbScreenCapture
from vision.ocr import PaddleOCRAdapter, choose_ocr_device


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--serial", default="127.0.0.1:5555")
    args = parser.parse_args()
    cap = AdbScreenCapture(serial=args.serial)
    source = ROOT / "data/observations/live/task_cancel_guild_selection_source.png"
    probe = ROOT / "data/observations/live/task_cancel_guild_selection_probe.png"
    cap.capture(source)
    if cv2.imread(str(source), cv2.IMREAD_COLOR) is None:
        print(json.dumps({"status": "safety_stop", "reason": "capture_failed"}, ensure_ascii=False))
        return 2
    try:
        lines = PaddleOCRAdapter.from_default_models(
            device=choose_ocr_device("gpu:0"), language="jpn"
        ).recognize(str(source))
    except Exception as exc:
        print(json.dumps({"status": "safety_stop", "reason": f"ocr_failed:{type(exc).__name__}"}, ensure_ascii=False))
        return 2
    text = "".join(x.text for x in lines if x.confidence >= .70).replace(" ", "")
    if "ギルド選択確認" not in text:
        print(json.dumps({"status": "safety_stop", "reason": "guild_confirm_not_verified", "text": text}, ensure_ascii=False))
        return 2
    found = [x for x in lines if x.bbox and x.confidence >= .70 and "キャンセル" in x.text.replace(" ", "")]
    if len(found) != 1:
        print(json.dumps({"status": "safety_stop", "reason": "cancel_not_unique", "count": len(found)}, ensure_ascii=False))
        return 2
    box = found[0].bbox
    x, y = int((box[0] + box[2]) / 2), int((box[1] + box[3]) / 2)
    if not (100 <= x <= 1100 and 560 <= y <= 700):
        print(json.dumps({"status": "safety_stop", "reason": "cancel_out_of_bounds", "x": x, "y": y}, ensure_ascii=False))
        return 2
    token = lambda: (cap.capture(probe), hashlib.sha1(probe.read_bytes()).hexdigest())[1]
    try:
        run_adb_coordinate_sequence(
            [(x, y)], serial=args.serial, healthcheck=True,
            timing_policy=AdaptiveWaitPolicy(), screen_probe=token,
            require_screen_change=True, previous_screen_token=token(),
            debug_capture_dir=ROOT / "data/observations/live",
            debug_capture_prefix="task_cancel_guild_selection",
        )
    except Exception as exc:
        print(json.dumps({"status": "safety_stop", "reason": f"tap_failed:{type(exc).__name__}"}, ensure_ascii=False))
        return 2
    print(json.dumps({"status": "cancelled", "screen": "guild_select", "x": x, "y": y}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
